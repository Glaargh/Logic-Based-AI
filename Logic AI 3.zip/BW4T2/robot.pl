:-dynamic in/1,			% matches the in/1 percept
	state/1,		% matches the state/1 percept
	zone/5,			% matches the zone/5 percept
	at/1,
	visited/1,
	atBlock/1,
	color/2,
	place/1,
	sequence/1,
	sequenceIndex/1,
	holding/1,
	block/2.				

	% A room is a place with exactly one neighbour, i.e., there is only one way to get to and from that place.
	room(PlaceID) :- zone(_,PlaceID,_,_,Neighbours), length(Neighbours,1).

	% Exercise 2.2: insert a definition of the predicate "nextColorInSeq(Color)".
	%nextColorInSeq(Color) is used to find the right color. sequence(Sequence) is used to access the sequence of block colors asked for, sequenceIndex(Index) tells you how far you are in the sequence,
	%nth0(Index,Sequence,Color) is used to combine the information of previous predicates to access the Color at the position given by Index in the Sequence.
	
	nextColorInSeq(Color) :- sequence(Sequence), sequenceIndex(Index), nth0(Index, Sequence, Color).
	
	%finished is used to check whether the bot has gotten every block in the sequence. sequenceIndex(Index) tells you how far you are in the sequence, sequence(Sequence) is used to access the sequence of block colors asked for and
	%length(Sequence,Index) checks whether the Sequence is as long as the Index indicates.
	finished :- sequenceIndex(Index), sequence(Sequence), length(Sequence,Index).
	